@extends('layouts.dashboard')

@section('content')
    ADMIN HOME
@endsection