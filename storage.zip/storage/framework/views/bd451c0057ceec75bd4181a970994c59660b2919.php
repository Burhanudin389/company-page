

<?php $__env->startSection('content'); ?>
    <div class="w-full p-3 md:p-5">
        <div class="max-w-screen-xl mx-auto">
            
            <div class="py-3 md:pb-5 flex justify-between items-center">
                <div class="py-3 md:py-5 flex justify-between">
                    <div id="breadcrumbs" class="flex items-center space-x-3">
                        <a href="<?php echo e(route('dashboard')); ?>" class="text-sm font-medium text-blue-500 hover:underline">Dashboard</a>
                        <span class="iconify" data-icon="bx:chevron-right"></span>
                        <p class="text-sm font-medium text-slate-500">Layout</p>
                        <span class="iconify" data-icon="bx:chevron-right"></span>
                        <p class="text-sm font-medium text-slate-500">Halaman tentang kami</p>
                    </div>
                </div>
            </div>
            <div class="flex flex-col space-y-6">
                <?php echo $__env->make('admin.privillege.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LETSDOTHIS\company-profile\resources\views/admin/layout/about.blade.php ENDPATH**/ ?>